package io.cortexj.runtime.remote;

import com.fasterxml.jackson.databind.JsonNode;
import io.cortexj.ErrorCode;
import io.cortexj.error.InferenceException;
import io.cortexj.error.ModelLoadException;
import io.cortexj.inference.EmbeddingRequest;
import io.cortexj.inference.EmbeddingResponse;
import io.cortexj.inference.FinishReason;
import io.cortexj.inference.GenerationRequest;
import io.cortexj.inference.GenerationResponse;
import io.cortexj.inference.InferenceRequest;
import io.cortexj.inference.InferenceResponse;
import io.cortexj.inference.RerankingRequest;
import io.cortexj.inference.RerankingResponse;
import io.cortexj.inference.TextGenerationCapability;
import io.cortexj.inference.TokenUsage;
import io.cortexj.model.ModelCapabilities;
import io.cortexj.model.TaskCapability;
import io.cortexj.observability.PlatformEventListener;
import io.cortexj.runtime.RuntimeId;
import io.cortexj.spi.runtime.ModelRuntime;
import io.cortexj.spi.runtime.RuntimeModel;
import io.cortexj.spi.runtime.RuntimeModelRequest;
import io.cortexj.stream.TokenStream;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class RemoteOpenAiRuntime implements ModelRuntime {

    private static final int SSE_POLL_MILLIS = 2_000;
    // audit #103: a generous timeout while waiting for the response headers -
    // a busy remote endpoint can take seconds to answer headers, and the old
    // 2s poll timeout failed such streams with false SocketTimeoutExceptions;
    // cancel() (which disconnects) remains the primary abort mechanism
    private static final int SSE_HEADER_TIMEOUT_MILLIS = 30_000;
    private static final long SSE_IDLE_CEILING_MILLIS = 300_000L;
    private static final int MAX_SSE_LINE_CHARS = 4 * 1024 * 1024;
    private static final int MAX_STREAMED_TOOL_CALLS = 128;
    private static final int MAX_STREAMED_TOOL_ARGS_CHARS = 4 * 1024 * 1024;

    /**
     * {@code HttpURLConnection.disconnect()} can block on the input-stream lock
     * held by a reader parked in a socket read, so it is issued from a
     * throwaway daemon thread: callers (close/cancel) never wait on it.
     */
    private static void disconnectAsync(final HttpURLConnection connection) {
        Thread disconnector = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    connection.disconnect();
                } catch (RuntimeException ignored) {
                }
            }
        }, "cortexj-remote-disconnect");
        disconnector.setDaemon(true);
        disconnector.start();
    }

    private static InferenceException closedDuringStream() {
        return new InferenceException(ErrorCode.INFERENCE_CANCELLED,
                "the model was closed while the stream was active",
                "Subscribe again after re-loading the model.");
    }

    private final RuntimeId runtimeId;
    private final String baseUrl;
    private final String apiKey;
    private final ExecutorService executor;
    private final boolean ownsExecutor;
    private final PlatformEventListener eventListener;

    private final HttpJsonClient client;
    private final java.util.concurrent.atomic.AtomicBoolean runtimeClosed =
            new java.util.concurrent.atomic.AtomicBoolean();
    private final java.util.Set<HttpURLConnection> liveStreams =
            java.util.Collections.newSetFromMap(
                    new java.util.concurrent.ConcurrentHashMap<HttpURLConnection, Boolean>());

    RemoteOpenAiRuntime(RuntimeId runtimeId, String baseUrl, String apiKey, ExecutorService executor, PlatformEventListener eventListener, HttpJsonClient client) {
        this.runtimeId = runtimeId;
        this.client = client == null ? new HttpJsonClient() : client;
        this.baseUrl = HttpJsonClient.trimSlash(baseUrl);
        this.apiKey = apiKey;
        this.ownsExecutor = executor == null;
        // audit 2026-10-07 (#146): the fallback pool is bounded like every
        // platform pool - newFixedThreadPool's unbounded queue used to absorb
        // stream storms without limit. Prefers the shared platform executor
        // (passed in) whenever core drives the load path.
        this.executor = executor == null
                ? new java.util.concurrent.ThreadPoolExecutor(4, 4,
                        60L, java.util.concurrent.TimeUnit.SECONDS,
                        new java.util.concurrent.LinkedBlockingQueue<Runnable>(64),
                        io.cortexj.spi.platform.PlatformModule.daemonThreadFactory("cortexj-remote-io"),
                        new java.util.concurrent.ThreadPoolExecutor.AbortPolicy())
                : executor;
        this.eventListener = eventListener == null ? PlatformEventListener.NOOP : eventListener;
    }

    @Override
    public RuntimeId runtimeId() {
        return runtimeId;
    }

    @Override
    public RuntimeModel load(RuntimeModelRequest request) {
        String model = modelIdFor(request);
        boolean rerankEnabled = Boolean.parseBoolean(
                String.valueOf(request.runtimeOptions().getOrDefault("enableRerank", "false")));
        return new RemoteModel(model, rerankEnabled);
    }

    private String modelIdFor(RuntimeModelRequest request) {
        Object override = request.runtimeOptions().get("model");
        if (override instanceof String && !((String) override).trim().isEmpty()) {
            return ((String) override).trim();
        }
        String fromArtifact = request.artifact() == null ? null : request.artifact().metadata().get("remoteModel");
        if (fromArtifact != null && !fromArtifact.isEmpty()) {
            return fromArtifact;
        }
        return request.model() == null ? "default" : request.model().canonicalId();
    }

    @Override
    public void close() {
        // audit M-8: disconnect every in-flight SSE connection first - socket
        // reads never respond to interrupts, so shutdownNow alone would leave
        // workers blocked for the full read timeout while the remote endpoint
        // keeps generating (and billing) server-side.
        // audit 2026-10-07 (#145): idempotent by flag - a repeated close must
        // not re-iterate liveStreams or re-shut the executor
        if (!runtimeClosed.compareAndSet(false, true)) {
            return;
        }
        for (HttpURLConnection connection : liveStreams) {
            try {
                disconnectAsync(connection);
            } catch (RuntimeException ignored) {
            }
        }
        if (ownsExecutor) {
            executor.shutdown();
            try {
                if (!executor.awaitTermination(5, java.util.concurrent.TimeUnit.SECONDS)) {
                    executor.shutdownNow();
                }
            } catch (InterruptedException e) {
                executor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }

    final class RemoteModel implements RuntimeModel, TextGenerationCapability,
            io.cortexj.inference.EmbeddingCapability, io.cortexj.inference.RerankingCapability {

        private final String modelId;
        private final boolean rerankEnabled;
        private volatile boolean closed;
        private final java.util.Set<HttpURLConnection> modelStreams =
                java.util.Collections.newSetFromMap(
                        new java.util.concurrent.ConcurrentHashMap<HttpURLConnection, Boolean>());

        RemoteModel(String modelId, boolean rerankEnabled) {
            this.modelId = modelId;
            this.rerankEnabled = rerankEnabled;
        }

        @Override
        public ModelCapabilities capabilities() {
            return ModelCapabilities.of(Collections.singleton(TaskCapability.TEXT_GENERATION), true, false, 8);
        }

        @Override
        public InferenceResponse execute(InferenceRequest request) {
            if (request.metadata().containsKey("task") && "embedding".equals(request.metadata().get("task"))) {
                EmbeddingResponse embedding = embed(EmbeddingRequest.texts(request.inputs()));
                List<String> outputs = new ArrayList<String>();
                for (float[] vector : embedding.vectors()) {
                    outputs.add(java.util.Arrays.toString(vector));
                }
                return new InferenceResponse(outputs, Collections.<String, Object>singletonMap("vectors", Integer.valueOf(embedding.vectors().size())));
            }
            GenerationResponse response = generate(GenerationRequest.prompt(request.singleInput()));
            return InferenceResponse.single(response.text());
        }

        @Override
        public CompletionStage<InferenceResponse> executeAsync(final InferenceRequest request) {
            if (executor == null) {
                try {
                    return CompletableFuture.completedFuture(execute(request));
                } catch (Throwable failure) {
                    CompletableFuture<InferenceResponse> failed = new CompletableFuture<InferenceResponse>();
                    failed.completeExceptionally(failure);
                    return failed;
                }
            }
            // audit 2026-10-08: a saturated/shut-down pool must surface as a
            // failed future, not a synchronous throw from an async contract
            try {
                return CompletableFuture.supplyAsync(new java.util.function.Supplier<InferenceResponse>() {
                    @Override
                    public InferenceResponse get() {
                        return execute(request);
                    }
                }, executor);
            } catch (java.util.concurrent.RejectedExecutionException saturated) {
                CompletableFuture<InferenceResponse> rejected =
                        new CompletableFuture<InferenceResponse>();
                rejected.completeExceptionally(new InferenceException(ErrorCode.INFERENCE_FAILED,
                        "Remote runtime overloaded: too many concurrent executions ("
                                + saturated.getMessage() + ").",
                        "Await or cancel an in-flight call before submitting more."));
                return rejected;
            }
        }

        @Override
        public GenerationResponse generate(GenerationRequest request) {
            requireOpen("generate");
            Map<String, Object> payload = generationPayload(request, false);
            HttpJsonClient.Response response = postJson("/v1/chat/completions", payload);
            if (!response.isOk()) {
                throw remoteError("generation failed", response);
            }
            JsonNode root = client.fromJson(response.body, JsonNode.class);
            JsonNode choice = root.path("choices").path(0);
            String text = choice.path("message").path("content").asText("");
            FinishReason finish = finishReason(choice.path("finish_reason").asText("stop"));
            TokenUsage usage = usageOf(root.path("usage"));
            JsonNode toolNode = choice.path("message").path("tool_calls");
            List<io.cortexj.model.ToolCall> toolCalls = toolNode.isArray()
                    ? toolCallsPayload(toolNode)
                    : java.util.Collections.<io.cortexj.model.ToolCall>emptyList();
            Map<String, String> metadata = Collections.singletonMap("remoteModel", modelId);
            if (toolCalls.isEmpty()) {
                return new GenerationResponse(text, finish, usage, metadata);
            }
            return new GenerationResponse(text, finish, usage, metadata, toolCalls);
        }

        @Override
        public TokenStream stream(GenerationRequest request) {
            requireOpen("stream");
            final Map<String, Object> payload = generationPayload(request, true);
            final io.cortexj.stream.internal.TokenStreamPublisher publisher = new io.cortexj.stream.internal.TokenStreamPublisher();
            // audit H-4: per-stream cancel plumbing - the cancel action wired into
            // the publisher disconnects the in-flight connection so the worker
            // stops reading (and the remote endpoint stops billing) immediately
            final java.util.concurrent.atomic.AtomicBoolean cancelled =
                    new java.util.concurrent.atomic.AtomicBoolean(false);
            final java.util.concurrent.atomic.AtomicReference<HttpURLConnection> activeConnection =
                    new java.util.concurrent.atomic.AtomicReference<HttpURLConnection>();
            publisher.onCancel(new Runnable() {
                @Override
                public void run() {
                    cancelled.set(true);
                    HttpURLConnection connection = activeConnection.get();
                    if (connection != null) {
                        disconnectAsync(connection);
                    }
                }
            });
            final Runnable worker = new Runnable() {
                @Override
                public void run() {
                    try {
                        streamSse(publisher, payload, cancelled, activeConnection);
                    } catch (final io.cortexj.error.CortexJException e) {
                        if (cancelled.get()) {
                            return;
                        }
                        if (closed || runtimeClosed.get()) {
                            // audit #95: close must deliver a terminal, not swallow it
                            publisher.fail(closedDuringStream());
                            return;
                        }
                        publisher.fail(e);
                    } catch (final Exception e) {
                        if (cancelled.get()) {
                            return;
                        }
                        if (closed || runtimeClosed.get()) {
                            publisher.fail(closedDuringStream());
                            return;
                        }
                        publisher.fail(new InferenceException(ErrorCode.INFERENCE_STREAM_FAILED,
                                "remote stream failed: " + e.getMessage(), e));
                    }
                }
            };
            if (executor != null) {
                try {
                    executor.execute(worker);
                } catch (java.util.concurrent.RejectedExecutionException saturated) {
                    publisher.fail(new InferenceException(ErrorCode.INFERENCE_STREAM_FAILED,
                            "Stream rejected: the IO executor queue is saturated ("
                                    + saturated.getMessage() + ").",
                            "Retry when in-flight streams drain or reduce concurrent streams."));
                }
            } else {
                worker.run();
            }
            return publisher.stream();
        }

        private void streamSse(io.cortexj.stream.internal.TokenStreamPublisher publisher, Map<String, Object> payload,
                               java.util.concurrent.atomic.AtomicBoolean cancelled,
                               java.util.concurrent.atomic.AtomicReference<HttpURLConnection> activeConnection) throws IOException {
            if (cancelled.get()) {
                return;
            }
            if (closed || runtimeClosed.get()) {
                // audit #95: a close must not swallow the terminal
                publisher.fail(closedDuringStream());
                return;
            }
            String endpointUrl = baseUrl + "/v1/chat/completions";
            try {
                io.cortexj.spi.support.HttpGuards.requirePublicHttpUrl(endpointUrl);
            } catch (IllegalArgumentException blocked) {
                throw new InferenceException(ErrorCode.INFERENCE_STREAM_FAILED,
                        "Remote stream URL blocked by the SSRF guard: " + blocked.getMessage(),
                        "Point the remote endpoint at a public URL or set "
                                + io.cortexj.spi.support.HttpGuards.ALLOW_PRIVATE_HOSTS_PROPERTY + "=true.");
            }
            URL url = new URL(endpointUrl);
            HttpURLConnection connection = client.openConnection(url);
            liveStreams.add(connection);
            modelStreams.add(connection);
            activeConnection.set(connection);
            try {
                if (cancelled.get()) {
                    disconnectAsync(connection);
                    return;
                }
                if (closed || runtimeClosed.get()) {
                    disconnectAsync(connection);
                    publisher.fail(closedDuringStream());
                    return;
                }
                connection.setRequestMethod("POST");
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(30_000);
                connection.setReadTimeout(SSE_HEADER_TIMEOUT_MILLIS);
                connection.setDoOutput(true);
                connection.setRequestProperty("Accept", "text/event-stream");
                connection.setRequestProperty("Content-Type", "application/json");
                if (apiKey != null && !apiKey.isEmpty()) {
                    connection.setRequestProperty("Authorization", "Bearer " + apiKey);
                }
                byte[] body = client.toJson(payload).getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(body.length);
                java.io.OutputStream output = connection.getOutputStream();
                try {
                    output.write(body);
                } finally {
                    output.close();
                }
                int status;
                try {
                    status = connection.getResponseCode();
                } catch (java.net.SocketTimeoutException headersNotAnswered) {
                    if (cancelled.get()) {
                        return;
                    }
                    if (closed || runtimeClosed.get()) {
                        publisher.fail(closedDuringStream());
                        return;
                    }
                    throw new InferenceException(ErrorCode.INFERENCE_STREAM_FAILED,
                            "the remote endpoint did not answer the stream request within "
                                    + SSE_HEADER_TIMEOUT_MILLIS + " ms",
                            "Check the remote endpoint health and its request queue.")
                            .detail("endpoint", io.cortexj.spi.support.HttpGuards.redactUrlForLogging(baseUrl));
                }
                if (status != 200) {
                    throw new InferenceException(ErrorCode.INFERENCE_STREAM_FAILED,
                            "remote stream request failed with HTTP " + status,
                            "Check the remote endpoint health and model id.")
                            .detail("status", String.valueOf(status));
                }
                connection.setReadTimeout(SSE_POLL_MILLIS);
                readSseStream(connection.getInputStream(), publisher, cancelled);
            } finally {
                liveStreams.remove(connection);
                modelStreams.remove(connection);
                activeConnection.compareAndSet(connection, null);
                disconnectAsync(connection);
            }
        }

        private void readSseStream(InputStream stream, io.cortexj.stream.internal.TokenStreamPublisher publisher,
                                   java.util.concurrent.atomic.AtomicBoolean cancelled) throws IOException {
            // the reader is deliberately NOT closed here: closing a chunked
            // stream blocks on the lock a parked read holds. The connection
            // is torn down asynchronously by streamSse's finally instead.
            final BufferedReader reader = new BufferedReader(
                    new InputStreamReader(stream, StandardCharsets.UTF_8));
            final Object eof = new Object();
            final java.util.concurrent.BlockingQueue<Object> queue =
                    new java.util.concurrent.LinkedBlockingQueue<Object>(1024);
            final java.util.concurrent.atomic.AtomicBoolean pumpStop =
                    new java.util.concurrent.atomic.AtomicBoolean(false);
            Thread pump = new Thread(new Runnable() {
                @Override
                public void run() {
                    StringBuilder partial = new StringBuilder(128);
                    try {
                        while (!pumpStop.get()) {
                            String next;
                            try {
                                next = readBoundedLine(reader, partial, MAX_SSE_LINE_CHARS);
                            } catch (java.net.SocketTimeoutException idle) {
                                continue;
                            }
                            Object item = next == null ? eof : next;
                            while (!pumpStop.get() && !queue.offer(item, 100, java.util.concurrent.TimeUnit.MILLISECONDS)) {
                                // consumer is slow: backpressure instead of unbounded buffering
                            }
                            if (next == null) {
                                return;
                            }
                        }
                    } catch (Throwable failure) {
                        // the failure must reach the consumer even when the
                        // buffer is full: evict buffered frames (the stream is
                        // failing, buffered items are discarded right after)
                        while (!queue.offer(failure)) {
                            queue.poll();
                        }
                    }
                }
            }, "cortexj-remote-sse-pump");
            pump.setDaemon(true);
            pump.start();
            try {
                FinishReason finish = FinishReason.STOP;
                long inputTokens = -1;
                long outputTokens = -1;
                long lastActivity = System.currentTimeMillis();
                // streamed tool calls arrive as index-keyed delta fragments:
                // id/name land once, function.arguments arrives in pieces
                java.util.Map<Integer, String[]> toolAccumulator =
                        new java.util.LinkedHashMap<Integer, String[]>();
                long totalToolArgsChars = 0L;
                while (!cancelled.get() && !closed && !runtimeClosed.get()) {
                    Object item;
                    try {
                        item = queue.poll(SSE_POLL_MILLIS, java.util.concurrent.TimeUnit.MILLISECONDS);
                    } catch (InterruptedException interrupted) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                    if (item == null) {
                        if (System.currentTimeMillis() - lastActivity >= SSE_IDLE_CEILING_MILLIS) {
                            throw new IOException("remote stream produced no data for "
                                    + SSE_IDLE_CEILING_MILLIS + " ms");
                        }
                        continue;
                    }
                    if (item == eof) {
                        break;
                    }
                    if (item instanceof IOException) {
                        throw (IOException) item;
                    }
                    if (item instanceof Throwable) {
                        throw new IOException(String.valueOf(((Throwable) item).getMessage()), (Throwable) item);
                    }
                    String line = (String) item;
                    lastActivity = System.currentTimeMillis();
                    if (line.isEmpty()) {
                        continue;
                    }
                    if (!line.startsWith("data:")) {
                        continue;
                    }
                    String data = line.substring(5).trim();
                    if (data.equals("[DONE]")) {
                        break;
                    }
                    JsonNode chunk = client.fromJson(data, JsonNode.class);
                    JsonNode choice = chunk.path("choices").path(0);
                    String delta = choice.path("delta").path("content").asText("");
                    if (!delta.isEmpty()) {
                        publisher.publish(delta);
                    }
                    JsonNode streamedToolCalls = choice.path("delta").path("tool_calls");
                    if (streamedToolCalls.isArray()) {
                        for (JsonNode toolNode : streamedToolCalls) {
                            int slot = toolNode.path("index").asInt(toolAccumulator.size());
                            if (slot < 0) {
                                slot = toolAccumulator.size();
                            }
                            if (slot >= MAX_STREAMED_TOOL_CALLS) {
                                throw new InferenceException(ErrorCode.INFERENCE_STREAM_FAILED,
                                        "remote stream exceeded maximum tool_calls index (" + MAX_STREAMED_TOOL_CALLS + ")",
                                        "Reduce the number of parallel tool calls requested.");
                            }
                            String[] acc = toolAccumulator.get(slot);
                            if (acc == null) {
                                if (toolAccumulator.size() >= MAX_STREAMED_TOOL_CALLS) {
                                    throw new InferenceException(ErrorCode.INFERENCE_STREAM_FAILED,
                                            "remote stream exceeded maximum tool_calls count (" + MAX_STREAMED_TOOL_CALLS + ")",
                                            "Reduce the number of parallel tool calls requested.");
                                }
                                acc = new String[]{"", "", ""};
                                toolAccumulator.put(slot, acc);
                            }
                            String id = toolNode.path("id").asText("");
                            if (!id.isEmpty()) {
                                acc[0] = id;
                            }
                            String name = toolNode.path("function").path("name").asText("");
                            if (!name.isEmpty() && acc[1].isEmpty()) {
                                acc[1] = name;
                            }
                            String argFragment = toolNode.path("function").path("arguments").asText("");
                            if (!argFragment.isEmpty()) {
                                totalToolArgsChars += argFragment.length();
                                if (totalToolArgsChars > MAX_STREAMED_TOOL_ARGS_CHARS) {
                                    throw new InferenceException(ErrorCode.INFERENCE_STREAM_FAILED,
                                            "remote stream exceeded maximum tool_calls arguments size ("
                                                    + MAX_STREAMED_TOOL_ARGS_CHARS + " chars)",
                                            "Check the remote endpoint's streaming tool_calls output.");
                                }
                                acc[2] += argFragment;
                            }
                        }
                    }
                    if (choice.has("finish_reason") && !choice.path("finish_reason").isNull()) {
                        finish = finishReason(choice.path("finish_reason").asText("stop"));
                    }
                    JsonNode usageNode = chunk.path("usage");
                    if (usageNode.has("prompt_tokens")) {
                        inputTokens = usageNode.path("prompt_tokens").asLong(-1);
                        outputTokens = usageNode.path("completion_tokens").asLong(-1);
                    }
                }
                if (cancelled.get()) {
                    // deliberately cancelled by the user: no terminal delivery
                    return;
                }
                if (closed || runtimeClosed.get()) {
                    // audit #95: model/platform close mid-stream must terminate
                    // the subscriber instead of leaving it waiting forever
                    publisher.fail(closedDuringStream());
                    return;
                }
                if (!toolAccumulator.isEmpty()) {
                    java.util.SortedSet<Integer> slots = new java.util.TreeSet<Integer>(toolAccumulator.keySet());
                    List<io.cortexj.model.ToolCall> calls = new ArrayList<io.cortexj.model.ToolCall>();
                    for (int slot : slots) {
                        String[] acc = toolAccumulator.get(slot);
                        if (acc[1].trim().isEmpty()) {
                            throw new InferenceException(ErrorCode.INFERENCE_FAILED,
                                    "streamed tool call carries no function name",
                                    "The OpenAI-compatible endpoint delivered an "
                                            + "incomplete tool_calls fragment; check the "
                                            + "endpoint's streaming implementation or "
                                            + "decline the tools.");
                        }
                        calls.add(new io.cortexj.model.ToolCall(acc[0], acc[1], acc[2]));
                    }
                    publisher.publishToolCalls(calls);
                }
                publisher.complete(finish, inputTokens, outputTokens);
            } finally {
                pumpStop.set(true);
            }
        }

        private String readBoundedLine(BufferedReader reader, StringBuilder sb, int maxChars) throws IOException {
            int c = reader.read();
            if (c < 0) {
                return null;
            }
            while (c >= 0) {
                if (c == '\n') {
                    break;
                }
                if (c != '\r') {
                    if (sb.length() >= maxChars) {
                        throw new IOException("remote SSE line exceeds maximum length of " + maxChars + " characters");
                    }
                    sb.append((char) c);
                }
                c = reader.read();
            }
            String line = sb.toString();
            sb.setLength(0);
            return line;
        }

        @Override
        public EmbeddingResponse embed(EmbeddingRequest request) {
            requireOpen("embed");
            Map<String, Object> payload = new LinkedHashMap<String, Object>();
            payload.put("model", modelId);
            payload.put("input", request.texts());
            HttpJsonClient.Response response = postJson("/v1/embeddings", payload);
            if (!response.isOk()) {
                throw remoteError("embedding failed", response);
            }
            JsonNode root = client.fromJson(response.body, JsonNode.class);
            List<float[]> vectors = new ArrayList<float[]>();
            for (JsonNode item : root.path("data")) {
                JsonNode embedding = item.path("embedding");
                float[] vector = new float[embedding.size()];
                for (int i = 0; i < embedding.size(); i++) {
                    vector[i] = (float) embedding.get(i).asDouble();
                }
                vectors.add(vector);
            }
            return new EmbeddingResponse(vectors);
        }

        @Override
        public RerankingResponse rerank(RerankingRequest request) {
            requireOpen("rerank");
            if (!rerankEnabled) {
                throw new InferenceException(ErrorCode.INFERENCE_UNSUPPORTED_TASK,
                        "Reranking is disabled for this remote model.",
                        "Enable it via runtime options: RuntimeOptions.forRuntime(\"openai-remote\").put(\"enableRerank\", true).");
            }
            Map<String, Object> payload = new LinkedHashMap<String, Object>();
            payload.put("model", modelId);
            payload.put("query", request.query());
            payload.put("documents", request.documents());
            HttpJsonClient.Response response = postJson("/v1/rerank", payload);
            if (!response.isOk()) {
                throw remoteError("reranking failed", response);
            }
            JsonNode root = client.fromJson(response.body, JsonNode.class);
            List<RerankingResponse.ScoredDocument> scores = new ArrayList<RerankingResponse.ScoredDocument>();
            for (JsonNode item : root.path("results")) {
                scores.add(new RerankingResponse.ScoredDocument(
                        item.path("index").asInt(0), item.path("relevance_score").asDouble(0.0d)));
            }
            return new RerankingResponse(scores);
        }

        @Override
        public void close() {
            closed = true;
            for (HttpURLConnection connection : modelStreams) {
                try {
                    disconnectAsync(connection);
                } catch (RuntimeException ignored) {
                }
            }
        }

        private void requireOpen(String operation) {
            // audit 2026-10-08: the runtime-level flag covers close() racing
            // new calls - the model flag alone let post-close generate/embed
            // walk into the network
            if (closed || runtimeClosed.get()) {
                throw new InferenceException(ErrorCode.INFERENCE_FAILED,
                        "Cannot " + operation + " on a closed remote model handle.",
                        "Create a new handle via CortexJ.models().load(...).");
            }
        }

        private Map<String, Object> generationPayload(GenerationRequest request, boolean stream) {
            Map<String, Object> payload = new LinkedHashMap<String, Object>();
            payload.put("model", modelId);
            List<Map<String, Object>> messages = new ArrayList<Map<String, Object>>();
            if (request.isChat()) {
                for (io.cortexj.model.ChatMessage message : request.messages()) {
                    messages.add(messagePayload(message));
                }
            } else {
                Map<String, Object> promptMessage = new LinkedHashMap<String, Object>();
                promptMessage.put("role", "user");
                promptMessage.put("content", request.prompt());
                messages.add(promptMessage);
            }
            payload.put("messages", messages);
            if (!request.tools().isEmpty()) {
                payload.put("tools", toolsPayload(request.tools()));
            }
            if (request.temperature() != null) {
                payload.put("temperature", request.temperature());
            }
            if (request.maxTokens() != null) {
                payload.put("max_tokens", request.maxTokens());
            }
            if (request.topP() != null) {
                payload.put("top_p", request.topP());
            }
            if (request.seed() != null) {
                payload.put("seed", request.seed());
            }
            if (!request.stopSequences().isEmpty()) {
                payload.put("stop", request.stopSequences());
            }
            if (stream) {
                payload.put("stream", Boolean.TRUE);
                payload.put("stream_options", Collections.singletonMap("include_usage", Boolean.TRUE));
            }
            return payload;
        }

        private Map<String, Object> messagePayload(io.cortexj.model.ChatMessage message) {
            Map<String, Object> payload = new LinkedHashMap<String, Object>();
            String role = message.role().name().toLowerCase();
            payload.put("role", role);
            payload.put("content", message.content());
            if (message.role() == io.cortexj.model.ChatRole.TOOL && !message.toolCallId().isEmpty()) {
                // the only link between an executed result and the call it answers;
                // legacy TOOL messages without an id render as plain tool text
                payload.put("tool_call_id", message.toolCallId());
            }
            if (!message.toolCalls().isEmpty()) {
                // assistant echo of the calls proposed in the previous round
                List<Map<String, Object>> toolCalls = new ArrayList<Map<String, Object>>();
                for (io.cortexj.model.ToolCall call : message.toolCalls()) {
                    Map<String, Object> wire = new LinkedHashMap<String, Object>();
                    wire.put("id", call.id());
                    wire.put("type", "function");
                    Map<String, Object> fn = new LinkedHashMap<String, Object>();
                    fn.put("name", call.name());
                    fn.put("arguments", call.arguments());
                    wire.put("function", fn);
                    toolCalls.add(wire);
                }
                payload.put("tool_calls", toolCalls);
            }
            return payload;
        }

        private List<Map<String, Object>> toolsPayload(List<io.cortexj.model.ToolDefinition> tools) {
            List<Map<String, Object>> payload = new ArrayList<Map<String, Object>>();
            for (io.cortexj.model.ToolDefinition tool : tools) {
                Map<String, Object> fn = new LinkedHashMap<String, Object>();
                fn.put("name", tool.name());
                fn.put("description", tool.description());
                if (!tool.parametersJson().isEmpty()) {
                    // the schema is JSON on the wire: parse it, never re-serialize as a string
                    try {
                        fn.put("parameters", client.fromJson(tool.parametersJson(),
                                com.fasterxml.jackson.databind.JsonNode.class));
                    } catch (IllegalArgumentException malformedSchema) {
                        // caller-side typo: fail with the tool named and the field
                        // to fix, not with a response-flavored message
                        throw new InferenceException(ErrorCode.CONF_INVALID,
                                "tool schema for '" + tool.name() + "' is not a valid JSON document",
                                "Fix the ToolDefinition parametersJson: it must be a valid JSON "
                                        + "document, e.g. {\\\"type\\\":\\\"object\\\"} - the provider "
                                        + "sends it to the endpoint verbatim as the argument schema.");
                    }
                }
                Map<String, Object> wire = new LinkedHashMap<String, Object>();
                wire.put("type", "function");
                wire.put("function", fn);
                payload.add(wire);
            }
            return payload;
        }

        private List<io.cortexj.model.ToolCall> toolCallsPayload(JsonNode array) {
            List<io.cortexj.model.ToolCall> calls = new ArrayList<io.cortexj.model.ToolCall>();
            for (JsonNode callNode : array) {
                String name = callNode.path("function").path("name").asText("");
                if (name.trim().isEmpty()) {
                    throw new InferenceException(ErrorCode.INFERENCE_FAILED,
                            "remote tool call carries no function name: "
                                    + abbreviate(callNode.toString()),
                            "The OpenAI-compatible endpoint returned a malformed "
                                    + "tool_calls entry; decline the tools or use a "
                                    + "provider that renders them correctly.");
                }
                calls.add(new io.cortexj.model.ToolCall(
                        callNode.path("id").asText(""),
                        name,
                        callNode.path("function").path("arguments").asText("")));
            }
            return calls;
        }

        private HttpJsonClient.Response postJson(String path, Map<String, Object> payload) {
            try {
                return client.post(baseUrl, path, client.toJson(payload), apiKey);
            } catch (IOException e) {
                InferenceException failure = new InferenceException(ErrorCode.INFERENCE_FAILED,
                        "Remote runtime call to " + path + " failed: " + e.getMessage(),
                        "Verify the endpoint URL and network connectivity.", e);
                failure.detail("endpoint", io.cortexj.spi.support.HttpGuards.redactUrlForLogging(baseUrl));
                throw failure;
            }
        }

        private InferenceException remoteError(String what, HttpJsonClient.Response response) {
            InferenceException failure = new InferenceException(ErrorCode.INFERENCE_FAILED,
                    "Remote runtime " + what + " with HTTP " + response.status + ": "
                            + abbreviate(response.body),
                    "Check the model id, endpoint configuration and API key.");
            failure.detail("status", String.valueOf(response.status));
            failure.detail("endpoint", io.cortexj.spi.support.HttpGuards.redactUrlForLogging(baseUrl));
            return failure;
        }

        private String abbreviate(String body) {
            if (body == null) {
                return "";
            }
            return body.length() <= 300 ? body : body.substring(0, 300) + "...";
        }

        private TokenUsage usageOf(JsonNode usageNode) {
            if (!usageNode.has("prompt_tokens")) {
                return null;
            }
            return new TokenUsage(
                    usageNode.path("prompt_tokens").asLong(-1),
                    usageNode.path("completion_tokens").asLong(-1));
        }

        private FinishReason finishReason(String value) {
            if ("length".equals(value)) {
                return FinishReason.LENGTH;
            }
            if ("content_filter".equals(value)) {
                return FinishReason.CONTENT_FILTER;
            }
            if ("tool_calls".equals(value)) {
                return FinishReason.TOOL_CALL;
            }
            return "stop".equals(value) ? FinishReason.STOP : FinishReason.OTHER;
        }
    }
}
