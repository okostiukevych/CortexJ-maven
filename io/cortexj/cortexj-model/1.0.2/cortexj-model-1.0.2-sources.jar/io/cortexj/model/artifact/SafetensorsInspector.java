package io.cortexj.model.artifact;

import io.cortexj.model.json.Json;
import io.cortexj.model.json.JsonReader;
import io.cortexj.model.ArtifactFormat;
import io.cortexj.spi.artifact.ArtifactInspection;
import io.cortexj.spi.artifact.ArtifactInspector;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;

public final class SafetensorsInspector implements ArtifactInspector {

    private static final int HEADER_LIMIT_BYTES = 64 * 1024 * 1024;
    // audit 2026-10-08: unbounded tensor-entry iteration allocates without
    // bound on hostile headers
    private static final int MAX_TENSOR_ENTRIES = 10_000_000;

    /** Hostile-header budget: nesting depth, number and string length caps. */
    static final Json.Limits HEADER_LIMITS = new Json.Limits(
            50, 10000L, 10L * 1024L * 1024L);


    @Override
    public boolean supports(ArtifactFormat format) {
        return format == ArtifactFormat.SAFETENSORS;
    }

    @Override
    public ArtifactInspection inspect(Path artifact) {
        long fileSize;
        try {
            fileSize = Files.size(artifact);
        } catch (IOException e) {
            throw new MalformedArtifactException("Cannot read safetensors artifact " + artifact + ": " + e.getMessage(), e);
        }
        try (InputStream input = new BufferedInputStream(Files.newInputStream(artifact), 64 * 1024)) {
            return inspectStream(input, fileSize);
        } catch (IOException e) {
            throw new MalformedArtifactException("Cannot read safetensors artifact " + artifact + ": " + e.getMessage(), e);
        }
    }

    public ArtifactInspection inspectStream(InputStream input) throws IOException {
        return inspectStream(input, Long.MAX_VALUE);
    }

    private ArtifactInspection inspectStream(InputStream input, long availableBytes) throws IOException {
        byte[] lengthBytes = new byte[8];
        readFully(input, lengthBytes);
        long headerLength = ByteBuffer.wrap(lengthBytes).order(ByteOrder.LITTLE_ENDIAN).getLong();
        if (headerLength <= 0 || headerLength > HEADER_LIMIT_BYTES) {
            throw new MalformedArtifactException("Not a safetensors file: unreasonable header length " + headerLength);
        }
        if (availableBytes != Long.MAX_VALUE && headerLength > availableBytes - 8L) {
            throw new MalformedArtifactException("Not a safetensors file: declared header length " + headerLength
                    + " exceeds file size " + availableBytes);
        }
        byte[] headerBytes = new byte[(int) headerLength];
        readFully(input, headerBytes);
        Json header;
        try {
            header = JsonReader.parse(headerBytes, HEADER_LIMITS);
        } catch (Json.JsonParseException malformed) {
            throw new MalformedArtifactException(
                    "Safetensors header is not valid JSON: " + malformed.getMessage());
        }

        ArtifactInspection.Builder builder = ArtifactInspection.builder(ArtifactFormat.SAFETENSORS);
        String architecture = null;
        String quantization = null;
        int tensorCount = 0;
        long parameterCount = 0;

        Json metadata = header.get("__metadata__");
        if (metadata != null && metadata.isObject()) {
            Iterator<String> fields = metadata.fieldNames();
            while (fields.hasNext()) {
                String field = fields.next();
                String value = metadata.get(field).asText("");
                builder.metadata(field, value);
                if (field.equalsIgnoreCase("architecture") || field.equalsIgnoreCase("architectures")) {
                    architecture = value;
                }
                if (field.equalsIgnoreCase("quantization") || field.equalsIgnoreCase("format")) {
                    quantization = value;
                }
            }
        }

        Iterator<String> tensorNames = header.fieldNames();
        while (tensorNames.hasNext()) {
            String name = tensorNames.next();
            if (name.equals("__metadata__")) {
                continue;
            }
            Json tensor = header.get(name);
            // audit 2026-10-08: unknown non-tensor entries must not NPE the
            // inspector (nor inflate the tensor count)
            if (tensor == null || !tensor.isObject() || !tensor.has("dtype")) {
                continue;
            }
            tensorCount++;
            // audit 2026-10-08: cap entries; reject negative dims instead of
            // masking them with max(1L) (which understated parameterCount)
            if (tensorCount > MAX_TENSOR_ENTRIES) {
                throw new MalformedArtifactException(
                        "Safetensors header declares too many tensors (cap " + MAX_TENSOR_ENTRIES + ")");
            }
            Json dtype = tensor.get("dtype");
            long[] shape = parseShape(tensor.get("shape"));
            // audit 2026-10-07: multiplyExact turns hostile dims into a typed
            // failure instead of a wrapped parameterCount that would
            // understate memory and risk OOM at load time.
            long elements = 1L;
            try {
                for (long dimension : shape) {
                    if (dimension < 0) {
                        throw new MalformedArtifactException(
                                "Safetensors tensor '" + name + "' has a negative dimension");
                    }
                    elements = Math.multiplyExact(elements, Math.max(1L, dimension));
                }
                parameterCount = Math.addExact(parameterCount, elements);
            } catch (ArithmeticException overflow) {
                throw new MalformedArtifactException(
                        "Safetensors tensor '" + name + "' has unreasonable dimensions (overflow)");
            }
            if (dtype != null && quantization == null && name.toLowerCase().contains("weight")) {
                quantization = dtype.asText();
            }
        }

        if (architecture != null) {
            builder.architecture(architecture);
        }
        if (quantization != null) {
            builder.quantization(quantization);
        }
        builder.parameterCount(parameterCount);
        builder.metadata("tensorCount", String.valueOf(tensorCount));
        return builder.build();
    }

    private static long[] parseShape(Json shapeNode) {
        if (shapeNode == null || !shapeNode.isArray()) {
            return new long[0];
        }
        long[] shape = new long[shapeNode.size()];
        for (int i = 0; i < shapeNode.size(); i++) {
            shape[i] = shapeNode.get(i).asLong();
        }
        return shape;
    }

    private static void readFully(InputStream input, byte[] target) throws IOException {
        int offset = 0;
        while (offset < target.length) {
            int read = input.read(target, offset, target.length - offset);
            if (read < 0) {
                throw new IOException("Truncated safetensors file");
            }
            offset += read;
        }
    }
}
