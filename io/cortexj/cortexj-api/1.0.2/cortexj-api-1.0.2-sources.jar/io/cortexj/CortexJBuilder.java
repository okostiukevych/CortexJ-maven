package io.cortexj;

import io.cortexj.error.ConfigurationException;
import io.cortexj.spi.policy.ExecutionPolicy;
import io.cortexj.spi.repository.ModelRepositoryProvider;
import io.cortexj.spi.repository.TokenSupplier;
import io.cortexj.spi.runtime.RuntimeProvider;
import io.cortexj.observability.PlatformEventListener;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.ServiceLoader;
import java.util.concurrent.ExecutorService;

public final class CortexJBuilder {

    private final List<RuntimeProvider> runtimeProviders = new ArrayList<RuntimeProvider>();
    private final List<ModelRepositoryProvider> repositoryProviders = new ArrayList<ModelRepositoryProvider>();
    private final List<ExecutionPolicy> executionPolicies = new ArrayList<ExecutionPolicy>();
    private final List<io.cortexj.spi.conversion.ModelConverter> converters =
            new ArrayList<io.cortexj.spi.conversion.ModelConverter>();
    private volatile io.cortexj.model.TrustPolicy trustPolicy = io.cortexj.model.TrustPolicy.ALLOW_UNSIGNED_WITH_WARNING;
    private volatile String proxyHost;
    private volatile String proxyPort;
    private final List<PlatformEventListener> eventListeners = new ArrayList<PlatformEventListener>();

    // volatile: the builder may be configured on one thread and consumed by
    // build()/Configuration.from() on another; the frozen flag orders the
    // freeze, and volatile fields give the consumer safe visibility
    private volatile boolean offline = offlineFromEnvironment();
    private volatile Path workingDirectory;
    private volatile Long memoryLimitBytes;
    private volatile Long maxArtifactBytes;
    private volatile TokenSupplier tokenSupplier;
    private volatile String remoteBaseUrl;
    private volatile String remoteApiKey;
    private volatile String remoteModelPrefix;
    private volatile ExecutorService executor;
    private volatile boolean allowRemoteRuntime = true;
    private volatile boolean asyncEventDelivery;
    private volatile boolean shutdownHook;
    private volatile boolean frozen;

    public CortexJBuilder runtimeProvider(RuntimeProvider provider) {
        ensureMutable();
        if (provider != null) {
            runtimeProviders.add(provider);
        }
        return this;
    }

    public CortexJBuilder repositoryProvider(ModelRepositoryProvider provider) {
        ensureMutable();
        if (provider != null) {
            repositoryProviders.add(provider);
        }
        return this;
    }

    public CortexJBuilder executionPolicy(ExecutionPolicy policy) {
        ensureMutable();
        if (policy != null) {
            executionPolicies.add(policy);
        }
        return this;
    }

    public CortexJBuilder eventListener(PlatformEventListener listener) {
        ensureMutable();
        if (listener != null) {
            eventListeners.add(listener);
        }
        return this;
    }

    public CortexJBuilder offlineMode(boolean offline) {
        ensureMutable();
        this.offline = offline;
        return this;
    }

    public CortexJBuilder workingDirectory(Path directory) {
        ensureMutable();
        this.workingDirectory = directory;
        return this;
    }

    public CortexJBuilder memoryLimitBytes(long bytes) {
        ensureMutable();
        this.memoryLimitBytes = Long.valueOf(bytes);
        return this;
    }

    public CortexJBuilder maxArtifactBytes(long bytes) {
        ensureMutable();
        this.maxArtifactBytes = Long.valueOf(bytes);
        return this;
    }

    public CortexJBuilder tokenSupplier(TokenSupplier supplier) {
        ensureMutable();
        this.tokenSupplier = supplier;
        return this;
    }

    public CortexJBuilder remoteBaseUrl(String baseUrl) {
        ensureMutable();
        this.remoteBaseUrl = baseUrl;
        return this;
    }

    public CortexJBuilder remoteApiKey(String apiKey) {
        ensureMutable();
        this.remoteApiKey = apiKey;
        return this;
    }

    public CortexJBuilder remoteModelPrefix(String prefix) {
        ensureMutable();
        this.remoteModelPrefix = prefix;
        return this;
    }

    public CortexJBuilder executor(ExecutorService executor) {
        ensureMutable();
        this.executor = executor;
        return this;
    }

    public CortexJBuilder allowRemoteRuntime(boolean allow) {
        ensureMutable();
        this.allowRemoteRuntime = allow;
        return this;
    }

    public CortexJBuilder trustPolicy(io.cortexj.model.TrustPolicy policy) {
        ensureMutable();
        this.trustPolicy = policy == null ? io.cortexj.model.TrustPolicy.ALLOW_UNSIGNED_WITH_WARNING : policy;
        return this;
    }

    /**
     * Async event delivery (audit L-9): platform events are dispatched on a
     * dedicated daemon thread through a bounded queue instead of the caller's
     * thread, so a slow listener cannot stall model loads or downloads.
     * Ordering between events is lost on queue overflow (events are dropped
     * and counted in the debug log). Synchronous delivery remains the default.
     */
    public CortexJBuilder asyncEventDelivery(boolean async) {
        ensureMutable();
        this.asyncEventDelivery = async;
        return this;
    }

    public boolean isAsyncEventDelivery() {
        return asyncEventDelivery;
    }

    /**
     * Opt-in JVM shutdown hook (audit #81): when enabled, the platform registers
     * a 'cortexj-shutdown' hook that closes the instance on JVM exit, releasing
     * model handles, executors and the event bus. Default false.
     */
    public CortexJBuilder shutdownHook(boolean hook) {
        ensureMutable();
        this.shutdownHook = hook;
        return this;
    }

    public boolean isShutdownHook() {
        return shutdownHook;
    }

    public CortexJBuilder proxy(String host, int port) {
        ensureMutable();
        if (host == null || host.trim().isEmpty()) {
            this.proxyHost = null;
            this.proxyPort = null;
            return this;
        }
        this.proxyHost = host.trim();
        this.proxyPort = String.valueOf(port);
        return this;
    }

    public List<RuntimeProvider> runtimeProviders() {
        return java.util.Collections.unmodifiableList(runtimeProviders);
    }

    public List<ModelRepositoryProvider> repositoryProviders() {
        return java.util.Collections.unmodifiableList(repositoryProviders);
    }

    public List<ExecutionPolicy> executionPolicies() {
        return java.util.Collections.unmodifiableList(executionPolicies);
    }

    public CortexJBuilder converter(io.cortexj.spi.conversion.ModelConverter converter) {
        ensureMutable();
        if (converter != null) {
            converters.add(converter);
        }
        return this;
    }

    public List<io.cortexj.spi.conversion.ModelConverter> converters() {
        return java.util.Collections.unmodifiableList(converters);
    }

    public io.cortexj.model.TrustPolicy trustPolicy() {
        return trustPolicy;
    }

    public String proxyHost() {
        return proxyHost;
    }

    public String proxyPort() {
        return proxyPort;
    }

    public List<PlatformEventListener> eventListeners() {
        return java.util.Collections.unmodifiableList(eventListeners);
    }

    public boolean isOffline() {
        return offline;
    }

    public Path workingDirectory() {
        return workingDirectory;
    }

    public Long memoryLimitBytes() {
        return memoryLimitBytes;
    }

    public Long maxArtifactBytes() {
        return maxArtifactBytes;
    }

    public TokenSupplier tokenSupplier() {
        return tokenSupplier;
    }

    public String remoteBaseUrl() {
        return remoteBaseUrl;
    }

    public String remoteApiKey() {
        return remoteApiKey;
    }

    public String remoteModelPrefix() {
        return remoteModelPrefix;
    }

    public ExecutorService executor() {
        return executor;
    }

    public boolean isRemoteRuntimeAllowed() {
        return allowRemoteRuntime;
    }

    public CortexJ build() {
        frozen = true;
        for (PlatformFactory factory : ServiceLoader.load(PlatformFactory.class, CortexJBuilder.class.getClassLoader())) {
            return factory.create(this);
        }
        throw new ConfigurationException(ErrorCode.CONF_BOOTSTRAP_MISSING,
                "No CortexJ platform implementation found on the classpath.",
                "Add the 'cortexj-core' dependency, or a 'cortexj-starter-java<version>' starter artifact.");
    }

    private void ensureMutable() {
        if (frozen) {
            throw new IllegalStateException(
                    "CortexJBuilder is frozen: the platform was already built. "
                            + "Create a new builder for a new configuration.");
        }
    }

    private static boolean offlineFromEnvironment() {
        String property = System.getProperty("cortexj.offline");
        if (property != null) {
            return Boolean.parseBoolean(property.trim());
        }
        String env = System.getenv("CORTEXJ_OFFLINE");
        return env != null && Boolean.parseBoolean(env.trim());
    }
}
