package io.cortexj.convert.safetensors;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.cortexj.convert.gguf.internal.GgufBinaryReader;
import io.cortexj.convert.gguf.internal.GgufBinaryWriter;
import io.cortexj.convert.gguf.internal.GgufDocument;
import io.cortexj.model.ArtifactFormat;
import io.cortexj.model.ModelArtifact;
import io.cortexj.spi.conversion.ConversionRequest;
import io.cortexj.spi.conversion.ConversionResult;
import io.cortexj.spi.conversion.ConversionSupport;
import io.cortexj.spi.conversion.ConverterId;
import io.cortexj.spi.conversion.ModelConverter;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Deterministic Safetensors -> GGUF container conversion:
 * F32/F16/BF16 and integer tensors are re-containerized byte-for-byte into a valid
 * GGUF layout; model metadata is derived from an adjacent config.json when present.
 *
 * <p>Honesty note: the output is a structurally valid GGUF file.
 * Whether a concrete runtime (llama.cpp) accepts the model additionally depends on
 * architecture-specific metadata that safetensors alone does not carry - the
 * provenance manifest records exactly which keys were derived and which were not.</p>
 */
public final class SafetensorsToGgufConverter implements ModelConverter {

    public static final String ID = "safetensors-to-gguf";

    private static final long SAFETENSORS_HEADER_LIMIT = 64L * 1024L * 1024L;

    @Override
    public ConverterId id() {
        return ConverterId.of(ID);
    }

    @Override
    public ConversionSupport evaluate(ConversionRequest request) {
        if (request.sourceArtifact().format() != ArtifactFormat.SAFETENSORS
                || request.targetFormat() != ArtifactFormat.GGUF) {
            return ConversionSupport.unsupported(
                    io.cortexj.planner.ReasonCode.FORMAT_UNSUPPORTED,
                    "safetensors-to-gguf converts safetensors to GGUF only");
        }
        // planning-time evaluate() is format-based only: the planner may propose the
        // conversion before the source artifact is materialized locally. convert()
        // fails honestly when the file is missing at execution time.
        return ConversionSupport.supported();
    }

    @Override
    public ConversionResult convert(ConversionRequest request) {
        Path source = request.sourcePath();
        Path temp = null;
        boolean moved = false;
        try {
            SafetensorsFile file = SafetensorsFile.read(source);
            Map<String, String> config = readAdjacentConfig(source);

            GgufDocument document = new GgufDocument();
            document.version = 3;
            String name = stripExtension(fileNameOf(source));
            document.upsert("general.name", GgufBinaryReader.Types.STRING, name);
            String architecture = config.get("model_type");
            if (architecture != null && !architecture.isEmpty()) {
                document.upsert("general.architecture", GgufBinaryReader.Types.STRING,
                        architecture);
                document.upsert(architecture + ".context_length",
                        GgufBinaryReader.Types.UINT32,
                        Long.valueOf(longOf(config, "max_position_embeddings", 4096)));
                document.upsert(architecture + ".embedding_length",
                        GgufBinaryReader.Types.UINT32,
                        Long.valueOf(longOf(config, "hidden_size", 0)));
                document.upsert(architecture + ".block_count",
                        GgufBinaryReader.Types.UINT32,
                        Long.valueOf(longOf(config, "num_hidden_layers", 0)));
                document.upsert(architecture + ".attention.head_count",
                        GgufBinaryReader.Types.UINT32,
                        Long.valueOf(longOf(config, "num_attention_heads", 0)));
                long hiddenSize = longOf(config, "hidden_size", 0);
                long headCount = longOf(config, "num_attention_heads", 0);
                long kvHeads = longOf(config, "num_key_value_heads", headCount);
                if (kvHeads <= 0) {
                    kvHeads = headCount;
                }
                // explicit head_dim wins (Qwen3-0.6B: 128 vs hidden/heads 64)
                long headDim = longOf(config, "head_dim",
                        headCount <= 0 ? 0 : hiddenSize / headCount);
                document.upsert(architecture + ".attention.head_count_kv",
                        GgufBinaryReader.Types.UINT32, Long.valueOf(kvHeads));
                document.upsert(architecture + ".attention.key_length",
                        GgufBinaryReader.Types.UINT32, Long.valueOf(headDim));
                document.upsert(architecture + ".attention.value_length",
                        GgufBinaryReader.Types.UINT32, Long.valueOf(headDim));
                document.upsert(architecture + ".feed_forward_length",
                        GgufBinaryReader.Types.UINT32,
                        Long.valueOf(longOf(config, "intermediate_size", 0)));
                float normEps = (float) doubleOf(config, "rms_norm_eps", 1e-6);
                document.upsert(architecture + ".attention.layer_norm_rms_epsilon",
                        GgufBinaryReader.Types.FLOAT32, Float.valueOf(normEps));
                document.upsert(architecture + ".rope.freq_base",
                        GgufBinaryReader.Types.FLOAT32,
                        Float.valueOf((float) doubleOf(config, "rope_theta", 10000.0)));
            }
            String tokenizerNote = writeTokenizer(document, source);
            document.upsert("general.file_type", GgufBinaryReader.Types.UINT32,
                    Long.valueOf("float16".equalsIgnoreCase(
                            String.valueOf(config.get("torch_dtype"))) ? 1 : 0));
            document.upsert("cortexj.converted_by", GgufBinaryReader.Types.STRING, ID);

            for (SafetensorsFile.TensorInfo tensor : file.tensors()) {
                document.tensors.add(new GgufDocument.TensorInfo(
                        ggufName(tensor.name, architecture), reversed(tensor.shape),
                        ggufTypeOf(tensor.dtype), 0L));
            }

            Path output = request.outputDirectory().resolve(name + ".gguf");
            Files.createDirectories(request.outputDirectory());
            temp = output.resolveSibling(output.getFileName() + ".part");
            try (InputStream input = new BufferedInputStream(
                    Files.newInputStream(source), 1 << 16);
                 OutputStream out = new BufferedOutputStream(
                         Files.newOutputStream(temp), 1 << 16)) {
                SafetensorsFile.skipHeader(input);
                GgufBinaryWriter writer = new GgufBinaryWriter(out);
                document.writeHeader(writer);
                byte[] buffer = new byte[1 << 16];
                for (SafetensorsFile.TensorInfo tensor : file.tensors()) {
                    copyExactly(input, out, tensor.byteSize, buffer);
                }
                writer.flush();
            }
            try {
                Files.move(temp, output, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicFailed) {
                Files.move(temp, output, StandardCopyOption.REPLACE_EXISTING);
            }
            moved = true;

            String sha256 = sha256Hex(output);
            Map<String, String> provenance = new LinkedHashMap<String, String>();
            provenance.put("converterId", ID);
            provenance.put("sourceArtifact", request.sourceArtifact().id());
            provenance.put("sourceBytes", String.valueOf(Files.size(source)));
            provenance.put("outputBytes", String.valueOf(Files.size(output)));
            provenance.put("tensorsConverted", String.valueOf(file.tensors().size()));
            provenance.put("configDerived", String.valueOf(architecture != null));
            provenance.put("tokenizer", tokenizerNote);
            provenance.put("outputChecksum", "sha256:" + sha256);

            Map<String, String> metadata =
                    new LinkedHashMap<String, String>(request.sourceArtifact().metadata());
            metadata.put("quantization", "fp16");
            metadata.put("convertedFrom", request.sourceArtifact().id());
            ModelArtifact artifact = new ModelArtifact.Abstract(
                    fileNameOf(output), ArtifactFormat.GGUF,
                    Files.size(output), null, metadata) {
            };
            return new ConversionResult(artifact, output, provenance);
        } catch (IOException e) {
            throw new io.cortexj.error.ConversionException(
                    io.cortexj.ErrorCode.CONVERSION_FAILED,
                    "safetensors to GGUF conversion failed: " + e.getMessage(),
                    "Verify the source file is a valid safetensors container.");
        } finally {
            if (!moved && temp != null) {
                // audit M-11: a mid-conversion failure must not strand a
                // model-sized partial next to the output
                try {
                    Files.deleteIfExists(temp);
                } catch (IOException ignored) {
                }
            }
        }
    }

    private static String fileNameOf(Path path) {
        java.nio.file.Path name = path == null ? null : path.getFileName();
        return name == null ? "" : name.toString();
    }

    /**
     * GGUF declares tensor dims innermost-first (reversed vs HF
     * row-major); the data bytes stay untouched, only the header
     * order flips. Verified against the official Qwen3 GGUF.
     */
    static long[] reversed(long[] shape) {
        long[] out = new long[shape.length];
        for (int i = 0; i < shape.length; i++) {
            out[i] = shape[shape.length - 1 - i];
        }
        return out;
    }

    /**
     * HF -> canonical GGUF tensor names for the llama family (read off
     * the official Qwen3 GGUF: token_embd, blk.N.attn_q/k/v/output,
     * attn_q/k_norm, attn_norm, ffn_gate/up/down, ffn_norm,
     * output_norm, output). Other architectures pass through untouched
     * (recorded in provenance, never guessed).
     */
    static String ggufName(String hfName, String modelType) {
        if (!"qwen2".equals(modelType) && !"qwen3".equals(modelType)
                && !"llama".equals(modelType) && !"mistral".equals(modelType)) {
            return hfName;
        }
        if ("model.embed_tokens.weight".equals(hfName)) {
            return "token_embd.weight";
        }
        if ("model.norm.weight".equals(hfName)) {
            return "output_norm.weight";
        }
        if ("lm_head.weight".equals(hfName)) {
            return "output.weight";
        }
        java.util.regex.Matcher layer =
                java.util.regex.Pattern.compile("^model\\.layers\\.(\\d+)\\.(.+)$")
                        .matcher(hfName);
        if (!layer.matches()) {
            return hfName;
        }
        String block = "blk." + layer.group(1) + ".";
        String rest = layer.group(2);
        if (rest.startsWith("self_attn.q_proj.")) {
            return block + "attn_q." + rest.substring("self_attn.q_proj.".length());
        }
        if (rest.startsWith("self_attn.k_proj.")) {
            return block + "attn_k." + rest.substring("self_attn.k_proj.".length());
        }
        if (rest.startsWith("self_attn.v_proj.")) {
            return block + "attn_v." + rest.substring("self_attn.v_proj.".length());
        }
        if (rest.startsWith("self_attn.o_proj.")) {
            return block + "attn_output." + rest.substring("self_attn.o_proj.".length());
        }
        if (rest.startsWith("self_attn.q_norm.")) {
            return block + "attn_q_norm." + rest.substring("self_attn.q_norm.".length());
        }
        if (rest.startsWith("self_attn.k_norm.")) {
            return block + "attn_k_norm." + rest.substring("self_attn.k_norm.".length());
        }
        if (rest.startsWith("mlp.gate_proj.")) {
            return block + "ffn_gate." + rest.substring("mlp.gate_proj.".length());
        }
        if (rest.startsWith("mlp.up_proj.")) {
            return block + "ffn_up." + rest.substring("mlp.up_proj.".length());
        }
        if (rest.startsWith("mlp.down_proj.")) {
            return block + "ffn_down." + rest.substring("mlp.down_proj.".length());
        }
        if (rest.startsWith("input_layernorm.")) {
            return block + "attn_norm." + rest.substring("input_layernorm.".length());
        }
        if (rest.startsWith("post_attention_layernorm.")) {
            return block + "ffn_norm." + rest.substring("post_attention_layernorm.".length());
        }
        return hfName;
    }

    private static int ggufTypeOf(String dtype) throws IOException {
        if ("F32".equals(dtype)) {
            return GgufDocument.TENSOR_F32;
        }
        if ("F16".equals(dtype)) {
            return GgufDocument.TENSOR_F16;
        }
        if ("BF16".equals(dtype)) {
            return GgufDocument.TENSOR_BF16;
        }
        if ("I64".equals(dtype)) {
            return 19;
        }
        if ("I32".equals(dtype)) {
            return 18;
        }
        if ("I16".equals(dtype)) {
            return 17;
        }
        if ("I8".equals(dtype) || "U8".equals(dtype) || "BOOL".equals(dtype)) {
            return 16;
        }
        throw new IOException("unsupported safetensors dtype for GGUF mapping: " + dtype);
    }

    private static long elementSize(String dtype) {
        if ("F32".equals(dtype) || "I32".equals(dtype) || "U32".equals(dtype)) {
            return 4L;
        }
        if ("F16".equals(dtype) || "BF16".equals(dtype) || "I16".equals(dtype)
                || "U16".equals(dtype)) {
            return 2L;
        }
        if ("F64".equals(dtype) || "I64".equals(dtype) || "U64".equals(dtype)) {
            return 8L;
        }
        return 1L;
    }

    private static ObjectMapper constrainedMapper() {
        // audit 2026-10-07: hostile headers must not StackOverflow the
        // converter - cap nesting depth and token/string budget
        ObjectMapper mapper = new ObjectMapper();
        mapper.getFactory().setStreamReadConstraints(
                com.fasterxml.jackson.core.StreamReadConstraints.builder()
                        .maxNestingDepth(50)
                        .maxNumberLength(10000)
                        .maxStringLength(10 * 1024 * 1024)
                        .build());
        return mapper;
    }

    private static Map<String, String> readAdjacentConfig(Path source) throws IOException {
        java.nio.file.Path parent = source.toAbsolutePath().getParent();
        Path config = parent == null ? null : parent.resolve("config.json");
        Map<String, String> flat = new LinkedHashMap<String, String>();
        if (config == null || !Files.isRegularFile(config)) {
            return flat;
        }
        // audit 2026-10-07: cap adjacent config.json - a hostile checkout
        // must not OOM the converter via readAllBytes.
        long size = Files.size(config);
        if (size > 16L * 1024L * 1024L) {
            throw new IOException("config.json is unreasonably large (" + size + " bytes, cap 16MB)");
        }
        ObjectMapper mapper = constrainedMapper();
        JsonNode root = mapper.readTree(Files.readAllBytes(config));
        flatten("", root, flat);
        return flat;
    }

    private static void flatten(String prefix, JsonNode node, Map<String, String> flat) {
        if (node.isObject()) {
            for (Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
                 fields.hasNext();) {
                Map.Entry<String, JsonNode> field = fields.next();
                flatten(prefix.isEmpty() ? field.getKey()
                        : prefix + "." + field.getKey(), field.getValue(), flat);
            }
            return;
        }
        flat.put(prefix, node.asText());
    }

    private static long longOf(Map<String, String> config, String key, long fallback) {
        String value = config.get(key);
        if (value == null) {
            return fallback;
        }
        try {
            return Long.parseLong(value.trim());
        } catch (NumberFormatException invalid) {
            return fallback;
        }
    }

    private static double doubleOf(Map<String, String> config, String key, double fallback) {
        String value = config.get(key);
        if (value == null) {
            return fallback;
        }
        try {
            return Double.parseDouble(value.trim());
        } catch (NumberFormatException invalid) {
            return fallback;
        }
    }

    /**
     * BPE tokenizer metadata for the verified qwen family (model=gpt2,
     * pre=qwen2 - read off the official Qwen3 GGUF): dense id->token
     * array, type array (normal/control/user-defined/unused PAD fill
     * for reserved ids), zero scores, merges, special ids. Other
     * architectures skip tokenizer emission (recorded, never guessed).
     * Returns the provenance note.
     */
    private static String writeTokenizer(GgufDocument document, Path source) throws IOException {
        java.nio.file.Path parent = source.toAbsolutePath().getParent();
        Path tokenizerJson = parent == null ? null : parent.resolve("tokenizer.json");
        Path tokenizerConfig = parent == null ? null : parent.resolve("tokenizer_config.json");
        if (tokenizerJson == null || !Files.isRegularFile(tokenizerJson)) {
            return "skipped (no adjacent tokenizer.json)";
        }
        Map<String, String> config = readAdjacentConfig(source);
        String modelType = config.get("model_type");
        if (!"qwen2".equals(modelType) && !"qwen3".equals(modelType)) {
            return "skipped (unverified family " + modelType + ", metadata only)";
        }
        long size = Files.size(tokenizerJson);
        if (size > 100L * 1024L * 1024L) {
            throw new IOException("tokenizer.json is unreasonably large (" + size
                    + " bytes, cap 100MB)");
        }
        ObjectMapper mapper = constrainedMapper();
        JsonNode root = mapper.readTree(Files.readAllBytes(tokenizerJson));
        JsonNode model = root.path("model");
        JsonNode vocab = model.path("vocab");
        if (!vocab.isObject()) {
            throw new IOException("tokenizer.json has no object vocab");
        }
        int vocabSize = longOf(config, "vocab_size", 0) > 0
                ? (int) longOf(config, "vocab_size", 0) : vocab.size();
        String[] tokens = new String[vocabSize];
        java.util.Iterator<String> names = vocab.fieldNames();
        while (names.hasNext()) {
            String name = names.next();
            int id = vocab.path(name).asInt(-1);
            if (id >= 0 && id < vocabSize) {
                tokens[id] = name;
            }
        }
        // added tokens (specials and user-defined) live in tokenizer_config.json
        java.util.Map<Integer, Boolean> addedSpecial = new java.util.LinkedHashMap<>();
        java.util.Map<String, Integer> addedIds = new java.util.LinkedHashMap<>();
        if (tokenizerConfig != null && Files.isRegularFile(tokenizerConfig)) {
            JsonNode added = mapper.readTree(Files.readAllBytes(tokenizerConfig))
                    .path("added_tokens_decoder");
            java.util.Iterator<String> ids = added.fieldNames();
            while (ids.hasNext()) {
                String idText = ids.next();
                try {
                    int id = Integer.parseInt(idText);
                    JsonNode entry = added.path(idText);
                    String content = entry.path("content").asText("");
                    if (id >= 0 && id < vocabSize && !content.isEmpty()) {
                        tokens[id] = content;
                        addedSpecial.put(Integer.valueOf(id),
                                Boolean.valueOf(entry.path("special").asBoolean(false)));
                        addedIds.put(content, Integer.valueOf(id));
                    }
                } catch (NumberFormatException ignored) {
                    // a non-numeric added-token key cannot map to an id: skip it loudly below
                }
            }
        }
        // reserved ids with no token anywhere become [PAD{id}] placeholders,
        // exactly like the official artifacts (type UNUSED)
        for (int id = 0; id < vocabSize; id++) {
            if (tokens[id] == null) {
                tokens[id] = "[PAD" + id + "]";
            }
        }
        List<Object> tokenList = new ArrayList<Object>();
        List<Object> typeList = new ArrayList<Object>();
        List<Object> scoreList = new ArrayList<Object>();
        for (int id = 0; id < vocabSize; id++) {
            tokenList.add(tokens[id]);
            scoreList.add(Float.valueOf(0.0f));
            typeList.add(Integer.valueOf(tokenTypeOf(id, tokens[id], addedSpecial)));
        }
        document.upsert("tokenizer.ggml.model", GgufBinaryReader.Types.STRING, "gpt2");
        document.upsert("tokenizer.ggml.pre", GgufBinaryReader.Types.STRING, "qwen2");
        document.upsert("tokenizer.ggml.tokens", GgufBinaryReader.Types.ARRAY,
                new GgufBinaryReader.ArrayValue(GgufBinaryReader.Types.STRING, tokenList));
        document.upsert("tokenizer.ggml.token_type", GgufBinaryReader.Types.ARRAY,
                new GgufBinaryReader.ArrayValue(GgufBinaryReader.Types.INT32, typeList));
        document.upsert("tokenizer.ggml.scores", GgufBinaryReader.Types.ARRAY,
                new GgufBinaryReader.ArrayValue(GgufBinaryReader.Types.FLOAT32, scoreList));
        List<Object> merges = new ArrayList<Object>();
        for (JsonNode merge : model.path("merges")) {
            // HF BPE merges serialize as ["a", "b"] pairs in some
            // tokenizers and "a b" strings in others; GGUF wants "a b"
            if (merge.isArray() && merge.size() == 2) {
                merges.add(merge.get(0).asText("") + " " + merge.get(1).asText(""));
            } else {
                merges.add(merge.asText(""));
            }
        }
        document.upsert("tokenizer.ggml.merges", GgufBinaryReader.Types.ARRAY,
                new GgufBinaryReader.ArrayValue(GgufBinaryReader.Types.STRING, merges));
        if (tokenizerConfig != null && Files.isRegularFile(tokenizerConfig)) {
            JsonNode configRoot = mapper.readTree(Files.readAllBytes(tokenizerConfig));
            int eos = specialId(configRoot, "eos_token", tokens, addedIds, -1);
            int bos = specialId(configRoot, "bos_token", tokens, addedIds, eos);
            int pad = specialId(configRoot, "pad_token", tokens, addedIds, -1);
            int unk = specialId(configRoot, "unk_token", tokens, addedIds, -1);
            if (eos >= 0) {
                document.upsert("tokenizer.ggml.eos_token_id",
                        GgufBinaryReader.Types.UINT32, Long.valueOf(eos));
            }
            if (bos >= 0) {
                document.upsert("tokenizer.ggml.bos_token_id",
                        GgufBinaryReader.Types.UINT32, Long.valueOf(bos));
            }
            if (pad >= 0) {
                document.upsert("tokenizer.ggml.padding_token_id",
                        GgufBinaryReader.Types.UINT32, Long.valueOf(pad));
            }
            if (unk >= 0) {
                document.upsert("tokenizer.ggml.unknown_token_id",
                        GgufBinaryReader.Types.UINT32, Long.valueOf(unk));
            }
            document.upsert("tokenizer.ggml.add_bos_token", GgufBinaryReader.Types.BOOL,
                    Boolean.valueOf(configRoot.path("add_bos_token").asBoolean(false)));
            String chatTemplate = configRoot.path("chat_template").asText("");
            if (!chatTemplate.isEmpty()) {
                document.upsert("tokenizer.chat_template",
                        GgufBinaryReader.Types.STRING, chatTemplate);
            }
        }
        return "qwen-bpe (pre=qwen2, " + vocabSize + " tokens, " + merges.size() + " merges)";
    }

    /** 1 normal, 2 unknown, 3 control, 4 user-defined, 6 byte, else 5 unused. */
    private static int tokenTypeOf(int id, String token,
                                   java.util.Map<Integer, Boolean> addedSpecial) {
        Boolean special = addedSpecial.get(Integer.valueOf(id));
        if (special != null) {
            return special.booleanValue() ? 3 : 4;
        }
        if (token.startsWith("<0x") && token.endsWith(">")) {
            return 6;
        }
        if (token.startsWith("[PAD") && token.endsWith("]")) {
            return 5;
        }
        return 1;
    }

    private static int specialId(JsonNode configRoot, String field, String[] tokens,
                                 java.util.Map<String, Integer> addedIds, int fallback) {
        JsonNode node = configRoot.path(field);
        if (node.isInt()) {
            int id = node.asInt(-1);
            return id >= 0 && id < tokens.length ? id : fallback;
        }
        String content = node.isTextual() ? node.asText("")
                : node.path("content").asText("");
        if (content.isEmpty()) {
            return fallback;
        }
        Integer added = addedIds.get(content);
        if (added != null) {
            return added.intValue();
        }
        for (int id = 0; id < tokens.length; id++) {
            if (content.equals(tokens[id])) {
                return id;
            }
        }
        return fallback;
    }

    private static void copyExactly(InputStream input, OutputStream output,
                                    long bytes, byte[] buffer) throws IOException {
        long remaining = bytes;
        while (remaining > 0) {
            int chunk = (int) Math.min(buffer.length, remaining);
            int read = input.read(buffer, 0, chunk);
            if (read < 0) {
                throw new IOException("safetensors data section is truncated");
            }
            output.write(buffer, 0, read);
            remaining -= read;
        }
    }

    private static String stripExtension(String fileName) {
        int dot = fileName.lastIndexOf('.');
        return dot > 0 ? fileName.substring(0, dot) : fileName;
    }

    private static String sha256Hex(Path file) throws IOException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (InputStream input = Files.newInputStream(file)) {
                byte[] buffer = new byte[1 << 16];
                int read;
                while ((read = input.read(buffer)) >= 0) {
                    digest.update(buffer, 0, read);
                }
            }
            StringBuilder hex = new StringBuilder();
            for (byte b : digest.digest()) {
                hex.append(String.format("%02x", b));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IOException("SHA-256 unavailable", e);
        }
    }

    static final class SafetensorsFile {

        static final class TensorInfo {
            final String name;
            final String dtype;
            final long[] shape;
            final long[] dataOffsets;
            final long byteSize;

            TensorInfo(String name, String dtype, long[] shape, long[] dataOffsets) {
                this.name = name;
                this.dtype = dtype;
                this.shape = shape;
                this.dataOffsets = dataOffsets;
                this.byteSize = dataOffsets[1] - dataOffsets[0];
            }
        }

        static SafetensorsFile read(Path file) throws IOException {
            try (InputStream input = Files.newInputStream(file)) {
                return read(input);
            }
        }

        static SafetensorsFile read(InputStream input) throws IOException {
            long headerSize = readInt64(input);
            if (headerSize <= 0 || headerSize > SAFETENSORS_HEADER_LIMIT) {
                throw new IOException("unreasonable safetensors header size: " + headerSize);
            }
            byte[] headerBytes = new byte[(int) headerSize];
            readFully(input, headerBytes);
            ObjectMapper mapper = constrainedMapper();
            JsonNode header = mapper.readTree(new String(headerBytes, StandardCharsets.UTF_8));

            // tensors sorted by their data offset: the safetensors layout guarantees
            // a contiguous, gap-free data section in this order
            Map<Long, TensorInfo> byOffset = new TreeMap<Long, TensorInfo>();
            List<String> unsupported = new ArrayList<String>();
            for (Iterator<Map.Entry<String, JsonNode>> fields = header.fields();
                 fields.hasNext();) {
                Map.Entry<String, JsonNode> field = fields.next();
                JsonNode entry = field.getValue();
                if (!entry.has("dtype")) {
                    continue; // __metadata__ or unknown non-tensor entries
                }
                String dtype = entry.path("dtype").asText();
                JsonNode shapeNode = entry.path("shape");
                long[] shape = new long[shapeNode.size()];
                for (int i = 0; i < shape.length; i++) {
                    shape[i] = shapeNode.get(i).asLong();
                }
                JsonNode offsets = entry.path("data_offsets");
                long[] pair = {offsets.get(0).asLong(), offsets.get(1).asLong()};
                // audit 2026-10-07: overlapping or inverted data_offsets would
                // silently duplicate/rewind bytes - reject the file instead.
                if (pair[1] < pair[0]) {
                    throw new IOException("safetensors tensor '" + field.getKey()
                            + "' has inverted data_offsets");
                }
                TensorInfo tensor = new TensorInfo(field.getKey(), dtype, shape, pair);
                if (byOffset.containsKey(Long.valueOf(pair[0]))) {
                    throw new IOException("safetensors tensor '" + field.getKey()
                            + "' overlaps another tensor at offset " + pair[0]);
                }
                byOffset.put(Long.valueOf(pair[0]), tensor);
            }
            if (byOffset.isEmpty()) {
                throw new IOException("safetensors header declares no tensors");
            }
            if (!unsupported.isEmpty()) {
                throw new IOException("unsupported dtypes: " + unsupported);
            }
            List<TensorInfo> ordered = new ArrayList<TensorInfo>(byOffset.values());
            for (int i = 0; i < ordered.size(); i++) {
                if (!supported(ordered.get(i).dtype)) {
                    throw new IOException("unsupported safetensors dtype: "
                            + ordered.get(i).dtype + " (tensor " + ordered.get(i).name + ")");
                }
            }
            return new SafetensorsFile(ordered, 8 + headerSize);
        }

        static void skipHeader(InputStream input) throws IOException {
            long headerSize = readInt64(input);
            if (headerSize <= 0 || headerSize > SAFETENSORS_HEADER_LIMIT) {
                throw new IOException("unreasonable safetensors header size: " + headerSize);
            }
            long remaining = headerSize;
            byte[] buffer = new byte[8192];
            while (remaining > 0) {
                int read = input.read(buffer, 0, (int) Math.min(buffer.length, remaining));
                if (read < 0) {
                    throw new IOException("truncated safetensors header");
                }
                remaining -= read;
            }
        }

        private static boolean supported(String dtype) {
            return "F32".equals(dtype) || "F16".equals(dtype) || "BF16".equals(dtype)
                    || "I64".equals(dtype) || "I32".equals(dtype) || "I16".equals(dtype)
                    || "I8".equals(dtype) || "U8".equals(dtype) || "BOOL".equals(dtype);
        }

        private static long readInt64(InputStream input) throws IOException {
            long value = 0L;
            for (int i = 0; i < 8; i++) {
                int b = input.read();
                if (b < 0) {
                    throw new IOException("truncated safetensors file");
                }
                value |= (b & 0xFFL) << (8 * i);
            }
            return value;
        }

        private static void readFully(InputStream input, byte[] target) throws IOException {
            int offset = 0;
            while (offset < target.length) {
                int read = input.read(target, offset, target.length - offset);
                if (read < 0) {
                    throw new IOException("truncated safetensors header");
                }
                offset += read;
            }
        }

        private final List<TensorInfo> tensors;
        final long headerBytes;

        SafetensorsFile(List<TensorInfo> tensors, long headerBytes) {
            this.tensors = tensors;
            this.headerBytes = headerBytes;
        }

        List<TensorInfo> tensors() {
            return tensors;
        }
    }
}
